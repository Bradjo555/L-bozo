* Alle variabelen in het Engels
* Altijd dubbele quotes gebruiken
